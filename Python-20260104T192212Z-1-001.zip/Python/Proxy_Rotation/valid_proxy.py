import requests
with open(r"C:\Users\Sai Abhijeet\Desktop\Python Parsing\Proxy\proxy.txt", "r") as f:
    proxies = f.read().split("\n")

sites_to_check = ["https://www.flipkart.com/search?q=television&as=on&as-show=on&otracker=AS_Query_HistoryAutoSuggest_1_5_na_na_na&otracker1=AS_Query_HistoryAutoSuggest_1_5_na_na_na&as-pos=1&as-type=HISTORY&suggestionId=television&requestId=6e08fb76-c252-4338-96fb-4c31d3b27a16&as-backfill=on"]
                  
counter = 0

for site in sites_to_check:
    try:
        print(f"Using the proxy: {proxies[counter]}")
        res = requests.get(site,proxies={"http": proxies[counter],
                                         "https": proxies[counter]})
        print(res.status_code)
        print(res.text)
    except:
        print("Failed")
    finally:
        counter += 1