import requests
from bs4 import BeautifulSoup
import csv

# Load proxies
proxy_path = r"C:\Users\Sai Abhijeet\Desktop\Python Parsing\Proxy\proxy39k.txt"
with open(proxy_path, "r") as f:
    proxies = [p.strip() for p in f if p.strip()]

if not proxies:
    raise ValueError("❌ No proxies found in valid_proxy.txt")


sites_to_check = []
base_url = "https://www.flipkart.com/search?q=laptops&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off&page={page}"
sites_to_check.append(base_url.format(page=1))

# Output CSV setup
csv_path = r"C:\Users\Sai Abhijeet\Desktop\Python Parsing\Proxy\laptop_flipkart.csv"
output_file = open(csv_path, "w", newline="", encoding="utf-8")
writer = csv.writer(output_file)
writer.writerow(["Name", "Price", "Image URL", "Description", "Rating"])

# Scraping loop
counter = 0
for site in sites_to_check:
    try:
        proxy = proxies[counter % len(proxies)]
        print(f"\n🔎 Checking Page {counter + 1} using proxy: {proxy}")
        
        res = requests.get(
            site,
            proxies={"http": proxy, "https": proxy},
            timeout=10,
            headers={"User-Agent": "Mozilla/5.0"}
        )

        print(f"✅ Status Code: {res.status_code}")
        soup = BeautifulSoup(res.text, "html.parser")
        products = soup.find_all("div", {"class": "_75nlfW"})

        print(f"📦 Found {len(products)} products")

        for product in products:
            name_tag = product.find("div", class_="KzDlHZ")
            price_tag = product.find("div", class_="Nx9bqj _4b5DiR")
            image_tag = product.find("img", class_="DByuf4")
            desc_tag = product.find("ul", class_="rgWa7D")  # Example class for description
            rating_tag = product.find("div", class_="XQDdHH")  # Example class for rating

            if name_tag and price_tag and image_tag:
                name = name_tag.text.strip()
                price = price_tag.text.strip()
                image_url = image_tag.get("src")
                description = desc_tag.text.strip() if desc_tag else "N/A"
                rating = rating_tag.text.strip() if rating_tag else "N/A"

                writer.writerow([name, price, image_url, description, rating])

                print(f"Name: {name}")
                print(f"Price: {price}")
                print(f"Image URL: {image_url}")
                print(f"Description: {description}")
                print(f"Rating: {rating}")
                print("-" * 60)

    except Exception as e:
        print(f"❌ Failed: {e}")
    finally:
        counter += 1
output_file.close()
print(f"\n✅ Data saved to: {csv_path}")