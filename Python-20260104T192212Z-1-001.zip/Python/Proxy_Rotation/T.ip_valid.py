import requests
from bs4 import BeautifulSoup
import csv
import time
import random
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import urllib3
from concurrent.futures import ThreadPoolExecutor
import threading

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class ProxyRotator:
    def __init__(self, proxies):
        self.proxies = proxies
        self.current_index = 0
        self.failed_proxies = set()
        self.lock = threading.Lock()
    
    def get_next_proxy(self):
        """Get next proxy in rotation, skip failed ones"""
        with self.lock:
            if not self.proxies or len(self.failed_proxies) >= len(self.proxies):
                return None
            
            attempts = 0
            while attempts < len(self.proxies):
                proxy = self.proxies[self.current_index]
                self.current_index = (self.current_index + 1) % len(self.proxies)
                
                if proxy not in self.failed_proxies:
                    return proxy
                
                attempts += 1
            
            return None
    
    def mark_failed(self, proxy):
        """Mark a proxy as failed"""
        with self.lock:
            self.failed_proxies.add(proxy)
            print(f"❌ Proxy marked as failed: {proxy}")
    
    def get_stats(self):
        """Get proxy stats"""
        with self.lock:
            total = len(self.proxies)
            failed = len(self.failed_proxies)
            working = total - failed
            return {"total": total, "working": working, "failed": failed}

def create_fast_session():
    """Create a fast session with minimal retries"""
    session = requests.Session()
    
    # Fast retry strategy - fail fast
    retry_strategy = Retry(
        total=2,
        backoff_factor=0.5,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS"]
    )
    
    adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=20, pool_maxsize=20)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    
    # Fast, minimal headers
    session.headers.update({
        'User-Agent': f'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{random.randint(115, 120)}.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive'
    })
    
    return session

def load_proxies(proxy_path):
    """Load proxies from file"""
    try:
        with open(proxy_path, "r") as f:
            proxies = [p.strip() for p in f if p.strip()]
        
        if not proxies:
            print("⚠️  No proxies found")
            return []
        
        print(f"✅ Loaded {len(proxies)} proxies")
        return proxies
    except FileNotFoundError:
        print("⚠️  Proxy file not found")
        return []

def scrape_page_fast(session, url, proxy_rotator, page_num, max_attempts=3):
    """Fast scraping with immediate proxy rotation on failure"""
    
    for attempt in range(max_attempts):
        proxy = proxy_rotator.get_next_proxy()
        
        try:
            # Quick header rotation
            session.headers.update({
                'User-Agent': f'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{random.randint(115, 120)}.0.0.0 Safari/537.36'
            })
            
            proxy_dict = {"http": proxy, "https": proxy} if proxy else None
            proxy_info = f"Proxy: {proxy}" if proxy else "Direct"
            
            print(f"🔄 Page {page_num} - Attempt {attempt + 1} - {proxy_info}")
            
            response = session.get(
                url,
                proxies=proxy_dict,
                timeout=8,  # Short timeout for fast failure
                allow_redirects=True,
                verify=False
            )
            
            if response.status_code == 200:
                print(f"✅ Page {page_num} success - {proxy_info}")
                return response
            else:
                print(f"❌ Page {page_num} status {response.status_code} - {proxy_info}")
                if proxy:
                    proxy_rotator.mark_failed(proxy)
                
        except (requests.exceptions.ReadTimeout, requests.exceptions.ConnectionError) as e:
            print(f"⏰ Page {page_num} timeout/connection error - {proxy_info}")
            if proxy:
                proxy_rotator.mark_failed(proxy)
        except Exception as e:
            print(f"❌ Page {page_num} error: {str(e)[:50]} - {proxy_info}")
            if proxy:
                proxy_rotator.mark_failed(proxy)
        
        # Quick delay before next attempt
        time.sleep(random.uniform(0.5, 1.5))
    
    return None

def extract_products_fast(html_content, page_num):
    """Fast product extraction with debugging and updated selectors"""
    try:
        soup = BeautifulSoup(html_content, "html.parser")
        
        # Enhanced blocking detection
        blocking_keywords = ["blocked", "captcha", "access denied", "robot", "automation", "suspicious"]
        if any(keyword in html_content.lower() for keyword in blocking_keywords):
            print(f"❌ Page {page_num} - Detected blocking")
            return []
        
        # Save page for debugging if needed
        if page_num <= 2:  # Only save first 2 pages for debugging
            debug_file = f"debug_page_{page_num}.html"
            with open(debug_file, "w", encoding="utf-8") as f:
                f.write(html_content)
            print(f"🔍 Page {page_num} saved for debugging: {debug_file}")
        
        # Comprehensive product selectors - including new ones
        product_selectors = [
            # New 2024 selectors
            "div[data-id]",
            "div._13oc-S",
            "div._1AtVbE",
            "div.col-7-12",
            "div._1fQZEK",
            "div.bhgxx2",
            "div._75nlfW",
            "div.cPHDOP",
            "div._2kHMtA",
            "div.col-12-12",
            # Link-based selectors
            "a[href*='/p/']",
            "a.s1Q9rs",
            "a._1fQZEK",
            # Container selectors
            "div[class*='product']",
            "div[class*='item']",
            "div[class*='card']"
        ]
        
        products = []
        used_selector = None
        
        print(f"🔍 Page {page_num} - Trying selectors...")
        
        for selector in product_selectors:
            try:
                found = soup.select(selector)
                print(f"   {selector}: {len(found)} elements")
                
                if len(found) > 5:  # Should have multiple products
                    products = found
                    used_selector = selector
                    break
                elif len(found) > 0:
                    # Check if these contain product-like content
                    for element in found[:3]:
                        text = element.get_text().lower()
                        if any(word in text for word in ["laptop", "₹", "rs", "price", "rating"]):
                            products = found
                            used_selector = selector
                            break
                    if products:
                        break
            except Exception as e:
                print(f"   {selector}: Error - {e}")
                continue
        
        if not products:
            print(f"❌ Page {page_num} - No products found with any selector")
            # Try generic selectors as last resort
            all_divs = soup.find_all("div")
            print(f"🔍 Page {page_num} - Total divs on page: {len(all_divs)}")
            
            # Look for text patterns that suggest products
            product_indicators = ["laptop", "₹", "rs.", "rating", "star", "off", "%"]
            potential_products = []
            
            for div in all_divs:
                text = div.get_text().lower()
                if any(indicator in text for indicator in product_indicators):
                    potential_products.append(div)
            
            print(f"🔍 Page {page_num} - Potential product divs: {len(potential_products)}")
            
            if potential_products:
                products = potential_products[:20]  # Limit to first 20
                used_selector = "text_pattern_matching"
            else:
                return []
        
        print(f"📦 Page {page_num} - Found {len(products)} products using: {used_selector}")
        
        extracted_data = []
        
        for i, product in enumerate(products):
            try:
                # Enhanced extraction with more selectors
                name_selectors = [
                    "div.KzDlHZ", "div._4rR01T", "a.s1Q9rs", "div.wjcEIp", 
                    "div._2WkVRV", "div.IRpwTa", "a._1fQZEK", "div._3pLy-c",
                    "div.col-7-12 div", "div._13oc-S div", "span[title]",
                    "a[title]", "div[title]", "h2", "h3", "h4"
                ]
                
                price_selectors = [
                    "div.Nx9bqj", "div._30jeq3", "div._25b18c", "div._1_WHN1",
                    "div._3tbKJL", "div._1vC4OE", "div._2rQ-NK", "span._1LkPcG",
                    "div._1AtVbE div", "span[class*='price']", "div[class*='price']"
                ]
                
                rating_selectors = [
                    "div.XQDdHH", "div._3LWZlK", "span._2_R_DZ", "div.hGSR34",
                    "span._1lRcqv", "div[class*='rating']", "span[class*='rating']"
                ]
                
                # Extract with multiple attempts
                name = extract_text_with_multiple_selectors(product, name_selectors)
                price = extract_text_with_multiple_selectors(product, price_selectors)
                rating = extract_text_with_multiple_selectors(product, rating_selectors)
                
                # Enhanced image extraction
                image_url = "N/A"
                img_selectors = ["img[src]", "img[data-src]", "img"]
                for img_selector in img_selectors:
                    img = product.select_one(img_selector)
                    if img:
                        image_url = img.get("src") or img.get("data-src") or "N/A"
                        if image_url and image_url != "N/A" and "http" in image_url:
                            break
                
                # Enhanced description extraction
                desc_selectors = [
                    "ul.rgWa7D", "div._1xgFaf", "div._16Jk6d", "ul._1xgFaf",
                    "div.fMghOz", "ul.vFw0gD", "div[class*='spec']", "ul"
                ]
                description = extract_text_with_multiple_selectors(product, desc_selectors)
                
                # More lenient data validation
                if name and name != "N/A" and len(name) > 3:
                    # Try to find price even if not in price selectors
                    if price == "N/A":
                        product_text = product.get_text()
                        import re
                        price_match = re.search(r'₹[\d,]+', product_text)
                        if price_match:
                            price = price_match.group()
                    
                    extracted_data.append({
                        "name": name,
                        "price": price,
                        "image_url": image_url,
                        "description": description,
                        "rating": rating
                    })
                    
                    print(f"   ✅ Product {i+1}: {name[:40]}... - {price}")
                
            except Exception as e:
                print(f"   ❌ Product {i+1} extraction error: {e}")
                continue
        
        print(f"✅ Page {page_num} - Extracted {len(extracted_data)} valid products")
        return extracted_data
        
    except Exception as e:
        print(f"❌ Page {page_num} - Parsing error: {str(e)}")
        return []

def extract_text_with_multiple_selectors(element, selectors):
    """Try multiple selectors and return first valid text"""
    for selector in selectors:
        try:
            found = element.select_one(selector)
            if found:
                text = found.get_text(strip=True)
                if text and len(text) > 0:
                    return text
        except:
            continue
    return "N/A"

def extract_text_fast(element, selector):
    """Fast text extraction"""
    try:
        found = element.select_one(selector)
        if found:
            text = found.get_text(strip=True)
            return text if text else None
    except:
        pass
    return None

def scrape_single_page(args):
    """Function to scrape a single page - for threading"""
    session, url, proxy_rotator, page_num = args
    
    response = scrape_page_fast(session, url, proxy_rotator, page_num)
    if response:
        return extract_products_fast(response.text, page_num)
    return []

def main():
    print("🚀 Fast Flipkart Scraper with Proxy Rotation")
    print("=" * 50)
    
    # Configuration
    proxy_path = r"C:\Users\Sai Abhijeet\Desktop\Python Parsing\Proxy\valid_proxy.txt"
    csv_path = r"C:\Users\Sai Abhijeet\Desktop\Python Parsing\Proxy\laptop_flipkart.csv"
    
    # Load proxies and create rotator
    proxies = load_proxies(proxy_path)
    proxy_rotator = ProxyRotator(proxies)
    
    # Create session
    session = create_fast_session()
    
    # Generate URLs
    base_url = "https://www.flipkart.com/search?q=laptops&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off&as-pos=1&as-type=HISTORY&page={page}"
    pages_to_scrape = list(range(1, 3))  # Pages 1-3
    
    # Setup CSV
    with open(csv_path, "w", newline="", encoding="utf-8") as output_file:
        writer = csv.writer(output_file)
        writer.writerow(["Name", "Price", "Image URL", "Description", "Rating"])
        
        total_products = 0
        successful_pages = 0
        
        # Method 1: Sequential scraping (faster proxy rotation)
        print("🔄 Starting sequential scraping...")
        
        for page_num in pages_to_scrape:
            start_time = time.time()
            
            url = base_url.format(page=page_num)
            products = scrape_single_page((session, url, proxy_rotator, page_num))
            
            if products:
                # Write to CSV immediately
                for product in products:
                    writer.writerow([
                        product["name"],
                        product["price"],
                        product["image_url"],
                        product["description"],
                        product["rating"]
                    ])
                    total_products += 1
                
                successful_pages += 1
                
                # Flush CSV to disk
                output_file.flush()
            
            # Stats
            stats = proxy_rotator.get_stats()
            elapsed = time.time() - start_time
            
            print(f"📊 Page {page_num} done in {elapsed:.1f}s | Products: {len(products)} | Proxies: {stats['working']}/{stats['total']} working")
            
            # Very short delay for speed
            time.sleep(random.uniform(0.5, 2))
            
            # Stop if all proxies failed and we have no direct connection success
            if stats['working'] == 0 and not proxies:
                print("⚠️  All proxies failed, stopping...")
                break
    
    print(f"\n🎉 SCRAPING COMPLETED!")
    print(f"=" * 40)
    print(f"📊 Total products: {total_products}")
    print(f"✅ Successful pages: {successful_pages}/{len(pages_to_scrape)}")
    print(f"💾 Data saved to: {csv_path}")
    
    # Final proxy stats
    final_stats = proxy_rotator.get_stats()
    print(f"🔄 Proxy performance: {final_stats['working']}/{final_stats['total']} working")

if __name__ == "__main__":
    main()