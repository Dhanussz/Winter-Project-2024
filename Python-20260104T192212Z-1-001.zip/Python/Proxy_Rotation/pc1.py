import requests
import time
import random
import os
from urllib.parse import urlparse

# Free proxy list source (updated hourly)
PROXY_SOURCE_URL = "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt"

# File to store current selected proxy
PROXY_FILE = "current_proxy.txt"

# Time interval to rotate proxy (in seconds) — 10 minutes
ROTATION_INTERVAL = 600

def fetch_proxies():
    """Fetch proxy list from public source."""
    try:
        print("[*] Fetching proxy list...")
        response = requests.get(PROXY_SOURCE_URL, timeout=10)
        response.raise_for_status()  # Raise an exception for bad status codes
        
        proxy_list = response.text.strip().split("\n")
        # Filter out empty lines and malformed entries
        proxy_list = [proxy.strip() for proxy in proxy_list if proxy.strip()]
        
        print(f"[*] Found {len(proxy_list)} proxies")
        return list(set(proxy_list))  # remove duplicates
    except Exception as e:
        print(f"[!] Failed to fetch proxies: {e}")
        return []

def validate_proxy_format(proxy):
    """Validate that proxy is in correct format (IP:PORT)."""
    try:
        if ':' not in proxy:
            return False
        ip, port = proxy.split(':', 1)
        # Basic validation
        port = int(port)
        return 1 <= port <= 65535 and len(ip.split('.')) == 4
    except:
        return False

def is_proxy_working(proxy):
    """Check if a proxy is working using httpbin."""
    if not validate_proxy_format(proxy):
        return False
        
    test_url = "https://httpbin.org/ip"
    proxies = {
        "http": f"http://{proxy}",
        "https": f"http://{proxy}"
    }
    try:
        response = requests.get(test_url, proxies=proxies, timeout=10)
        if response.status_code == 200:
            # Optionally verify the IP changed
            data = response.json()
            print(f"[+] Proxy {proxy} working - IP: {data.get('origin', 'unknown')}")
            return True
        return False
    except requests.exceptions.RequestException as e:
        print(f"[-] Proxy {proxy} failed: {type(e).__name__}")
        return False
    except Exception as e:
        print(f"[-] Proxy {proxy} error: {e}")
        return False

def get_valid_proxies(proxy_list, max_to_check=15):
    """Validate a few proxies from the list."""
    if not proxy_list:
        print("[!] No proxies to validate")
        return []
        
    print(f"[*] Validating up to {max_to_check} proxies...")
    valid = []
    
    # Shuffle the list to get different proxies each time
    random.shuffle(proxy_list)
    
    for i, proxy in enumerate(proxy_list[:max_to_check]):
        print(f"[*] Testing proxy {i+1}/{min(max_to_check, len(proxy_list))}: {proxy}")
        if is_proxy_working(proxy):
            valid.append(proxy)
            # Stop after finding a few working proxies
            if len(valid) >= 3:
                break
        time.sleep(0.5)  # Small delay between tests
    
    print(f"[*] Found {len(valid)} valid proxies")
    return valid

def load_current_proxy():
    """Load the current proxy from file if it exists."""
    if os.path.exists(PROXY_FILE):
        try:
            with open(PROXY_FILE, "r") as f:
                return f.read().strip()
        except:
            pass
    return None

def save_proxy(proxy):
    """Save proxy to file."""
    try:
        with open(PROXY_FILE, "w") as f:
            f.write(proxy)
        print(f"[✓] Proxy saved to {PROXY_FILE}")
        return True
    except Exception as e:
        print(f"[!] Failed to save proxy: {e}")
        return False
        
def rotate_proxy():
    """Main loop to rotate proxy every ROTATION_INTERVAL seconds."""
    print("[*] Starting proxy rotation service...")
    
    # Check if we have a current proxy
    current_proxy = load_current_proxy()
    if current_proxy:
        print(f"[*] Current proxy: {current_proxy}")
        # Test if current proxy still works
        if is_proxy_working(current_proxy):
            print("[*] Current proxy still working, will rotate after interval")
        else:
            print("[*] Current proxy not working, rotating immediately")
            ROTATION_INTERVAL = 0
    
    while True:
        try:
            proxies = fetch_proxies()
            if not proxies:
                print("[!] No proxies fetched, retrying in 5 minutes...")
                time.sleep(300)
                continue
                
            valid_proxies = get_valid_proxies(proxies)

            if valid_proxies:
                selected_proxy = random.choice(valid_proxies)
                if save_proxy(selected_proxy):
                    print(f"[✓] Proxy rotated: {selected_proxy}")
                else:
                    print("[!] Failed to save proxy")
            else:
                print("[!] No valid proxies found this round.")
                print("[*] Will retry in 5 minutes...")
                time.sleep(300)
                continue

            print(f"[*] Sleeping for {ROTATION_INTERVAL // 60} minutes...")
            time.sleep(ROTATION_INTERVAL)
            
        except KeyboardInterrupt:
            print("\n[*] Stopping proxy rotation service...")
            break
        except Exception as e:
            print(f"[!] Unexpected error: {e}")
            print("[*] Retrying in 2 minutes...")
            time.sleep(120)

def test_current_proxy():
    """Test the currently saved proxy."""
    current_proxy = load_current_proxy()
    if current_proxy:
        print(f"[*] Testing current proxy: {current_proxy}")
        if is_proxy_working(current_proxy):
            print("[✓] Current proxy is working")
        else:
            print("[!] Current proxy is not working")
    else:
        print("[!] No current proxy found")

if __name__ == "__main__":
    # Fixed the typo here - was "_main_" instead of "__main__"
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        test_current_proxy()
    else:
        rotate_proxy()